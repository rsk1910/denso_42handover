#include <IcsBaseClass.h>
#include <IcsHardSerialClass.h>

// ==== 設定 ====
const byte EN_PIN = 2;              
const long ICS_BAUDRATE = 115200;   
const int TIMEOUT = 10;

// ==== サーボID ====
const byte SERVO_ID_ELEVATOR = 1;
const byte SERVO_ID_RUDDER = 0;

// ==== アナログ入力 ====
const int VRx = A0; //要確認
const int VRy = A1; //要確認
const int trim_up = 6; //要確認
const int trim_down = 7; //要確認


// ==== パラメータ ====
//const float eleMax = 250.0;
const float eleMax = 400.0;
const float rudMax = 1000.0;
//const float rudMax = 400.0;
const float trim_Min = 13.9;

float aEle = 0.0;
float aRud = 0.0;

const int ELEVATOR_BASE = 8750; 
const int RUDDER_BASE = 9170;

// ==== トリム ====
int trim_value = 0;
const int trim_step = 20;
const int trim_Max = 1300;

long previous;
const int trim_interval = 50;
const int button_wait = 50;

long previousTrim = 0;
long previousSend = 0;


IcsHardSerialClass krs(&Serial1, EN_PIN, ICS_BAUDRATE, TIMEOUT);

void writeInt16BE(HardwareSerial &serial, int16_t val) {
  serial.write((uint8_t)(val >> 8));
  serial.write((uint8_t)(val & 0xFF));
}


void setup() {
  Serial.begin(115200);
  Serial2.begin(9600);  
  krs.begin();
  pinMode(VRx, INPUT);
  pinMode(VRy, INPUT);
  pinMode(trim_up,INPUT_PULLUP);
  pinMode(trim_down,INPUT_PULLUP);
  delay(1000);
  Serial.println("Control Ready");
}

void loop() {


    // ==== トリム制御 ====
  if (digitalRead(trim_up) == LOW) {
    if (millis() - previousTrim > button_wait) {
      trim_value += trim_step;
      previousTrim = millis();
    }
  }

  if (digitalRead(trim_down) == LOW) {
    if (millis() - previousTrim > button_wait) {
      trim_value -= trim_step;
      previousTrim = millis();
    }
  }

  trim_value = constrain(trim_value, -trim_Max, trim_Max);

  
  // === ジョイスティック入力 ===
  aEle = 0.15 * (512 - analogRead(VRx) ) / 512.0 + 0.85 * aEle;  
  if (fabs(aEle) < 0.02) aEle = 0.0;             
  aEle = constrain(aEle, -1.0, 1.0);


  aRud = 0.15 * (analogRead(VRy) - 512) / 512.0 + 0.85 * aRud;  
  if (fabs(aRud) < 0.02) aRud = 0.0;             
  aRud = constrain(aRud, -1.0, 1.0);

  // === サーボ位置 ===
  int posEle = (int)(ELEVATOR_BASE +trim_value - eleMax * aEle);
  int posRud = (int)(RUDDER_BASE - rudMax * aRud);

  
  krs.setPos(SERVO_ID_ELEVATOR, posEle);
  krs.setPos(SERVO_ID_RUDDER, posRud);


  if (millis() - previousSend > trim_interval){
  previousSend = millis();
  Serial2.write("HELLO", 5);
  writeInt16BE(Serial2, (int16_t)posRud);
  writeInt16BE(Serial2, (int16_t)posEle);
  writeInt16BE(Serial2, (int16_t)trim_value);
}

  // デバッグ出力
  Serial.print("Ele: "); 
  Serial.println(posEle);
  Serial.print("Rud: "); 
  Serial.println(posRud);


  delay(50);
}