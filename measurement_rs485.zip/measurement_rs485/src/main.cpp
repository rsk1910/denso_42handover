#include <Arduino.h>
#include <M5CoreS3.h>
#include <SoftwareSerial.h>
#define sensor_t sensor_t_
#include <Adafruit_Sensor.h>
#include <Adafruit_BMP280.h>
#undef sensor_t
#include <M5_IMU_PRO.h>
#include <MadgwickAHRS.h>
#include <MahonyAHRS.h>
#include <esp32/rom/crc.h>
#include <WiFi.h>
#include <WiFiUDP.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <SD.h>
#include <mbedtls/md.h>
#include <WiFiClientSecure.h>
#include <MQTTClient.h>
#include <ctime>
#include "secrets.h"




HTTPClient wifiHttp;         
const int HTTP_PORT = 35481; 
const int SD_MONITOR_PORT = 35482;

constexpr int USB_BAUDRATE = 115200;

//SoftwareSerial ALTSerial;
//constexpr int ALT_SERIAL_BAUDRATE = 9600;
constexpr int ALT_trig = 9, ALT_echo = 8;

#define COMMSerial Serial2
constexpr int COMM_SERIAL_BAUDRATE = 9600;
constexpr int COMM_RX = 17, COMM_TX = 18;
uint32_t comm_receive_count = 0;
uint32_t last_comm_time = 0;

constexpr int RPM_PIN = 10;
constexpr int TACHO_PIN[2] = {1, 2};
constexpr int SD_SPI_SCK_PIN = 36;
constexpr int SD_SPI_MISO_PIN = 35;
constexpr int SD_SPI_MOSI_PIN = 37;
constexpr int SD_SPI_CS_PIN = 4;

float rudder_rotation = 0.0f;
float elevator_rotation = 0.0f;
int trim = 0;

int watchdog_count;

#pragma region BMP280
// 気圧計による気圧、温度の測定及び高度の計算
constexpr int BMP280_SENSOR_ADDR = 0x76;
Adafruit_BMP280 bmp(&Wire1);
float ground_pressure = 1013.25f;
float temperature = 0;
float pressure = 0;
float bmp_altitude = 0;

void InitBMP280()
{
  if (!bmp.begin(BMP280_SENSOR_ADDR))
  {
    Serial.println("BMP280 init failed!");
    return;
  }
  Serial.println("BMP280 OK!");

  delay(100);

  ground_pressure = bmp.readPressure() / 100.0f;
}
void GetBMP280()
{
  temperature = bmp.readTemperature();
  pressure = bmp.readPressure() / 100.0f;
  bmp_altitude = bmp.readAltitude(ground_pressure);
}
#pragma endregion

#pragma region BMI270
// 6軸+3軸センサによる姿勢角の計算
constexpr int BIM270_SENSOR_ADDR = 0x68;
constexpr int AHRS_SAMPLING = 100;

BMI270::BMI270 bmi270;
Madgwick ahrs_madgwick_6dof, ahrs_madgwick_9dof;
Mahony ahrs_mahony_6dof, ahrs_mahony_9dof;

float accelX, accelY, accelZ;
float gyroX, gyroY, gyroZ;
int16_t magX, magY, magZ;

float roll_mad6 = 0, pitch_mad6 = 0, yaw_mad6 = 0;
float roll_mad9 = 0, pitch_mad9 = 0, yaw_mad9 = 0;
float roll_mah6 = 0, pitch_mah6 = 0, yaw_mah6 = 0;
float roll_mah9 = 0, pitch_mah9 = 0, yaw_mah9 = 0;

void ahrs_task(void *pvParameters)
{
  while (1)
  {
    ahrs_madgwick_6dof.updateIMU(gyroX, gyroY, gyroZ, accelX, accelY, accelZ);
    ahrs_madgwick_9dof.update(gyroX, gyroY, gyroZ, accelX, accelY, accelZ, magX, magY, magZ);
    ahrs_mahony_6dof.updateIMU(gyroX, gyroY, gyroZ, accelX, accelY, accelZ);
    ahrs_mahony_9dof.update(gyroX, gyroY, gyroZ, accelX, accelY, accelZ, magX, magY, magZ);

    roll_mad6 = ahrs_madgwick_6dof.getRoll();
    roll_mad6 = roll_mad6 < 0 ? roll_mad6 + 180.0f : roll_mad6 - 180.0f;
    pitch_mad6 = ahrs_madgwick_6dof.getPitch();
    yaw_mad6 = ahrs_madgwick_6dof.getYaw();

    roll_mad9 = ahrs_madgwick_9dof.getRoll();
    roll_mad9 = roll_mad9 < 0 ? roll_mad9 + 180.0f : roll_mad9 - 180.0f;
    pitch_mad9 = ahrs_madgwick_9dof.getPitch();
    yaw_mad9 = ahrs_madgwick_9dof.getYaw();

    roll_mah6 = ahrs_mahony_6dof.getRoll();
    roll_mah6 = roll_mah6 < 0 ? roll_mah6 + 180.0f : roll_mah6 - 180.0f;
    pitch_mah6 = ahrs_mahony_6dof.getPitch();
    yaw_mah6 = ahrs_mahony_6dof.getYaw();

    roll_mah9 = ahrs_mahony_9dof.getRoll();
    roll_mah9 = roll_mah9 < 0 ? roll_mah9 + 180.0f : roll_mah9 - 180.0f;
    pitch_mah9 = ahrs_mahony_9dof.getPitch();
    yaw_mah9 = ahrs_mahony_9dof.getYaw();

    delay(AHRS_SAMPLING / 4);
  }
}

void InitBMI270()
{
  if (!bmi270.init(I2C_NUM_1, BIM270_SENSOR_ADDR))
  {
    Serial.println("Failed to find BMI270");
    return;
  }

  ahrs_madgwick_6dof.begin(AHRS_SAMPLING);
  ahrs_madgwick_9dof.begin(AHRS_SAMPLING);
  ahrs_mahony_6dof.begin(AHRS_SAMPLING);
  ahrs_mahony_9dof.begin(AHRS_SAMPLING);

  xTaskCreatePinnedToCore(ahrs_task, "ahrs_task", 2048, NULL, 1, NULL, 0);

  Serial.println("BMI270 OK!");
}
void GetBMI270()
{
  bmi270.readAcceleration(accelX, accelY, accelZ);
  bmi270.readGyroscope(gyroX, gyroY, gyroZ);
  bmi270.readMagneticField(magX, magY, magZ);
}
#pragma endregion

#pragma region WIFI_LOCATION

double gps_latitude = 0;      // 緯度
double gps_longitude = 0;     // 経度
double gps_accuracy = 0;      // 推定誤差半径(m)
uint16_t gps_year = 0;        // 西暦
uint8_t gps_month = 0;        // 月
uint8_t gps_day = 0;          // 日
uint8_t gps_hour = 0;         // 時
uint8_t gps_minute = 0;       // 分
uint8_t gps_second = 0;       // 秒
uint8_t gps_centisecond = 0;  // センチ秒
double gps_altitude = 0;      
double gps_course = 0;        
double gps_speed = 0;        

constexpr uint32_t WIFI_LOCATION_INTERVAL_MS = 30000;
bool wifi_location_valid = false;

void GetWiFiLocation()
{
  if (WiFi.status() != WL_CONNECTED)
  {
    return;
  }

  int n = WiFi.scanNetworks();

  if (WiFi.status() != WL_CONNECTED)
  {
    Serial.println("WiFi Location: reconnecting after scan...");
    WiFi.reconnect();
  }

  if (n <= 0)
  {
    Serial.println("WiFi Location: No networks found");
    WiFi.scanDelete();
    return;
  }

  JsonDocument reqDoc;
  reqDoc["considerIp"] = false;
  JsonArray wifiAccessPoints = reqDoc["wifiAccessPoints"].to<JsonArray>();
  for (int i = 0; i < n; i++)
  {
    JsonObject ap = wifiAccessPoints.add<JsonObject>();
    ap["macAddress"] = WiFi.BSSIDstr(i);
    ap["signalStrength"] = WiFi.RSSI(i);
  }
  WiFi.scanDelete();

  String requestBody;
  serializeJson(reqDoc, requestBody);

  if (WiFi.status() != WL_CONNECTED)
  {
    return;
  }

  HTTPClient geoHttp;
  String url = "https://www.googleapis.com/geolocation/v1/geolocate?key=" + String(GOOGLE_GEOLOCATION_API_KEY);
  geoHttp.begin(url);
  geoHttp.addHeader("Content-Type", "application/json");

  int httpCode = geoHttp.POST(requestBody);
  if (httpCode == 200)
  {
    String response = geoHttp.getString();
    JsonDocument resDoc;
    DeserializationError jsonErr = deserializeJson(resDoc, response);
    if (!jsonErr)
    {
      gps_latitude = resDoc["location"]["lat"] | 0.0;
      gps_longitude = resDoc["location"]["lng"] | 0.0;
      gps_accuracy = resDoc["accuracy"] | 0.0;
      wifi_location_valid = true;
    }
    else
    {
      Serial.print("WiFi Location: JSON parse error: ");
      Serial.println(jsonErr.c_str());
    }
  }
  else
  {
    Serial.printf("WiFi Location: HTTP error %d\r\n", httpCode);
  }
  geoHttp.end();
}

void WiFiLocationTask(void *pvParameters)
{
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
  }

  while (1)
  {
    GetWiFiLocation();
    delay(WIFI_LOCATION_INTERVAL_MS);
  }
}

void InitWiFiLocation()
{
  xTaskCreatePinnedToCore(WiFiLocationTask, "WiFiLocationTask", 8192, NULL, 1, NULL, 1);
}
#pragma endregion

#pragma region NTP
constexpr long JST_OFFSET_SEC = 9 * 3600;
constexpr int DST_OFFSET_SEC = 0;
constexpr char NTP_SERVER1[] = "ntp.nict.jp";
constexpr char NTP_SERVER2[] = "pool.ntp.org";

bool ntp_synced = false;

void InitNTP()
{
  configTime(JST_OFFSET_SEC, DST_OFFSET_SEC, NTP_SERVER1, NTP_SERVER2);
}

void GetNTPTime()
{
  struct tm timeinfo;
  if (getLocalTime(&timeinfo, 100))
  {
    gps_year = timeinfo.tm_year + 1900;
    gps_month = timeinfo.tm_mon + 1;
    gps_day = timeinfo.tm_mday;
    gps_hour = timeinfo.tm_hour;
    gps_minute = timeinfo.tm_min;
    gps_second = timeinfo.tm_sec;
    gps_centisecond = 0;
    ntp_synced = true;
  }
}
#pragma endregion

#pragma region ALTITUDE

float altitude = 0; 


void InitAltitude()
{
  pinMode(ALT_trig, OUTPUT);
  pinMode(ALT_echo, INPUT);
  digitalWrite(ALT_trig, LOW);
}

void GetAltitude()
{
  digitalWrite(ALT_trig, LOW);
  delayMicroseconds(2);
  digitalWrite(ALT_trig, HIGH);
  delayMicroseconds(10);
  digitalWrite(ALT_trig, LOW);

  unsigned long duration = pulseIn(ALT_echo, HIGH, 30000);
  if (duration > 0)
  {
    altitude = duration * 0.0343f / 2.0f;
    altitude = altitude / 100;
  }
}
#pragma region TACHO

hw_timer_t *timer = NULL;

volatile uint16_t tach_interrupts = 0;

boolean slit_rori_last = true;

uint32_t tach_rotation = 0;
uint32_t tach_last_time = 0;
uint32_t tach_delta_time = 0;

float air_speed = 30.0;

const uint32_t min_tach_delta = 150000;

void GetTacho()
{
  tach_delta_time = micros() - tach_last_time;

  if (tach_delta_time > min_tach_delta)
  {
    noInterrupts();
    if (tach_interrupts > 5)
    {
      tach_rotation = (uint32_t)((double)1000000000.0 * ((double)tach_interrupts / tach_delta_time));
      air_speed = tach_rotation * tach_rotation * -7.0 * pow(10, -16.0) + tach_rotation * 3.0 * pow(10, -7.0);
    }
    else
    {
      tach_rotation = 0;
      air_speed = 0;
    }
    interrupts();
    tach_interrupts = 0;
    tach_last_time = micros();
  }
}

void IRAM_ATTR tach_interrupt_count()
{
  if (digitalRead(TACHO_PIN[0]) != slit_rori_last)
  {
    tach_interrupts++;
    slit_rori_last = !slit_rori_last;
  }
}

void InitTacho()
{
  pinMode(TACHO_PIN[0], INPUT);
  pinMode(TACHO_PIN[1], INPUT);

  interrupts();
  timer = timerBegin(0, getApbFrequency() / 1000000, true);
  timerAttachInterrupt(timer, &tach_interrupt_count, true);
  timerAlarmWrite(timer, 20, true);
  timerAlarmEnable(timer);
  tach_last_time = micros();
}
#pragma endregion

#pragma region ROTATION_SPEED
// 回転数計のコード
const int SLIT_NUM = 36;
volatile uint16_t propeller_interrupts = 0;
uint32_t propeller_rotation = 106666;
uint32_t propeller_last_time = 0;
#define min_interrupts 5

uint32_t propeller_delta_time = 0;

const uint32_t min_propeller_delta = 500000;

void propeller_interrupt_count()
{
  propeller_interrupts++;
}

void attachPropeller()
{
  attachInterrupt(digitalPinToInterrupt(RPM_PIN), propeller_interrupt_count, CHANGE);
}

void detachPropeller()
{
  detachInterrupt(digitalPinToInterrupt(RPM_PIN));
}

void GetRPM()
{
  propeller_delta_time = micros() - propeller_last_time;
  if (propeller_delta_time > min_propeller_delta)
  {
    detachPropeller(); 
    if (propeller_interrupts > min_interrupts)
    {
      // propeller_rotation = 割り込み数 / (スリット数 * 2.0)
      propeller_rotation = propeller_interrupts / (2.0 * SLIT_NUM) / (propeller_delta_time / 1000000.0) * 60.0;
    }
    else
    {
      propeller_rotation = 0;
    }
    attachPropeller();
    propeller_interrupts = 0;
    propeller_last_time = micros();
  }
}

void InitRPM()
{
  pinMode(RPM_PIN, INPUT_PULLUP);

  attachPropeller();
  interrupts();
  propeller_last_time = micros();
}
#pragma endregion

volatile bool sd_card_ok = false;        
volatile uint32_t sd_log_count = 0;      
volatile uint32_t sd_write_errors = 0;   
volatile uint32_t sd_last_write_ms = 0;  
volatile uint32_t sd_file_size = 0;      


#pragma region COMM

void GetControlData()
{
  static const char header[] = "HELLO";
  static uint8_t headerIndex = 0;
  static bool headerFound = false;
  static uint8_t buf[6];
  static uint8_t bufIndex = 0;

  while (COMMSerial.available())
  {
    uint8_t b = COMMSerial.read();

    if (!headerFound)
    {
      if (b == (uint8_t)header[headerIndex])
      {
        headerIndex++;
        if (headerIndex == 5)
        {
          headerFound = true;
          bufIndex = 0;

          comm_receive_count++;
          last_comm_time = millis();
        }
      }
      else
      {
        headerIndex = (b == (uint8_t)header[0]) ? 1 : 0;
      }
    }
    else
    {
      buf[bufIndex++] = b;
      if (bufIndex >= sizeof(buf))
      {
        int16_t rud = (int16_t)((buf[0] << 8) | buf[1]);
        int16_t ele = (int16_t)((buf[2] << 8) | buf[3]);
        int16_t trm = (int16_t)((buf[4] << 8) | buf[5]);

        rudder_rotation = rud;
        elevator_rotation = ele;
        trim = trm;

        headerFound = false;
        headerIndex = 0;
        bufIndex = 0;
      }
    }
  }
}
#pragma endregion

#pragma region LOG
// ログをmicroSDに保存
File fp;
constexpr char FILE_PATH[] = "/data.csv";
#define PRINT_COMMA fp.print(", ")

void InitSD();

void SDWriteTask(void *pvParameters)
{
  SPI.begin(SD_SPI_SCK_PIN, SD_SPI_MISO_PIN, SD_SPI_MOSI_PIN, SD_SPI_CS_PIN);

  if (!SD.begin(SD_SPI_CS_PIN, SPI, 25000000))
  {
    sd_card_ok = false;   // ★追加：SDカード自体を検出できなかった
    delay(5000);
    InitSD();
    vTaskDelete(NULL);
    return;
  }
  sd_card_ok = true;      // ★追加：これが抜けていたのが今回のバグの原因

  if (!SD.exists(FILE_PATH))
  {
    fp = SD.open(FILE_PATH, FILE_WRITE);

    // 基準値の設定
    fp.println(
        "Date,Time,Latitude,Longitude,GPSAltitude,GPSCourse,GPSSpeed,"
        "AccelX,AccelY,AccelZ,GyroX,GyroY,GyroZ,MagX,MagY,MagZ,"
        "Roll_Mad6,Pitch_Mad6,Yaw_Mad6,Roll_Mad9,Pitch_Mad9,Yaw_Mad9,"
        "Roll_Mah6,Pitch_Mah6,Yaw_Mah6,Roll_Mah9,Pitch_Mah9,Yaw_Mah9,"
        "Temperature,Pressure,GroundPressure,BMPAltitude,Altitude,AirSpeed,"
        "PropellerRotationSpeed,Rudder,Elevator,Trim,RunningTime");
  }
  else
  {
    fp = SD.open(FILE_PATH, FILE_APPEND);
  }

  if (!fp)                
  {
    sd_card_ok = false;
    delay(2000);
    InitSD();
    vTaskDelete(NULL);
    return;
  }

  uint32_t start_time = millis();

  while (fp)
  {
    fp.printf("%04d-%02d-%02d", gps_year, gps_month, gps_day);
    PRINT_COMMA;
    fp.printf("%02d:%02d:%02d.%02d", gps_hour, gps_minute, gps_second, gps_centisecond);
    PRINT_COMMA;
    fp.printf("%.9f", gps_latitude);
    PRINT_COMMA;
    fp.printf("%.9f", gps_longitude);
    PRINT_COMMA;
    fp.print(gps_altitude);
    PRINT_COMMA;
    fp.print(gps_course);
    PRINT_COMMA;
    fp.print(gps_speed);
    PRINT_COMMA;
    fp.print(accelX);
    PRINT_COMMA;
    fp.print(accelY);
    PRINT_COMMA;
    fp.print(accelZ);
    PRINT_COMMA;
    fp.print(gyroX);
    PRINT_COMMA;
    fp.print(gyroY);
    PRINT_COMMA;
    fp.print(gyroZ);
    PRINT_COMMA;
    fp.print(magX);
    PRINT_COMMA;
    fp.print(magY);
    PRINT_COMMA;
    fp.print(magZ);
    PRINT_COMMA;
    fp.print(roll_mad6);
    PRINT_COMMA;
    fp.print(pitch_mad6);
    PRINT_COMMA;
    fp.print(yaw_mad6);
    PRINT_COMMA;
    fp.print(roll_mad9);
    PRINT_COMMA;
    fp.print(pitch_mad9);
    PRINT_COMMA;
    fp.print(yaw_mad9);
    PRINT_COMMA;
    fp.print(roll_mah6);
    PRINT_COMMA;
    fp.print(pitch_mah6);
    PRINT_COMMA;
    fp.print(yaw_mah6);
    PRINT_COMMA;
    fp.print(roll_mah9);
    PRINT_COMMA;
    fp.print(pitch_mah9);
    PRINT_COMMA;
    fp.print(yaw_mah9);
    PRINT_COMMA;
    fp.print(temperature);
    PRINT_COMMA;
    fp.print(pressure);
    PRINT_COMMA;
    fp.print(ground_pressure);
    PRINT_COMMA;
    fp.print(bmp_altitude);
    PRINT_COMMA;
    fp.print(altitude);
    PRINT_COMMA;
    fp.print(air_speed);
    PRINT_COMMA;
    fp.print(propeller_rotation);
    PRINT_COMMA;
    fp.printf("%.3f", rudder_rotation);
    PRINT_COMMA;
    fp.printf("%.3f", elevator_rotation);
    PRINT_COMMA;
    fp.printf("%d", trim);
    PRINT_COMMA;
    fp.print(millis() / 1000.0);
    PRINT_COMMA;
    size_t written = fp.println();

    if (written > 0)                 
    {
      sd_log_count++;
      sd_last_write_ms = millis();
      sd_file_size = fp.size();
    }
    else
    {
      sd_write_errors++;
    }
 
    delay(50);

    if (millis() - start_time > 10000)
    {
      // 10秒ごとにファイルを閉じて再オープン
      break;
    }
  }

  fp.close();
  SD.end();
  InitSD();
  vTaskDelete(NULL);
}

void InitSD()
{
  xTaskCreatePinnedToCore(SDWriteTask, "SDWriteTask", 4096, NULL, 1, NULL, 0);
}
#pragma endregion

#pragma region JSON
// JSONを作成する
JsonDocument json_data, json_array;
char json_string[4096];

void CreateJson()
{
  // JSONに変換したいデータを連想配列で指定する
  char date_str[32], time_str[32];
  sprintf(date_str, "%04d-%02d-%02d", gps_year, gps_month, gps_day);
  sprintf(time_str, "%02d:%02d:%02d.%02d", gps_hour, gps_minute, gps_second, gps_centisecond);
  json_data["Date"] = date_str;
  json_data["Time"] = time_str;
  json_data["Latitude"] = gps_latitude;
  json_data["Longitude"] = gps_longitude;
  json_data["GPSAltitude"] = gps_altitude;
  json_data["GPSCourse"] = gps_course;
  json_data["GPSSpeed"] = gps_speed;
  json_data["AccelX"] = accelX;
  json_data["AccelY"] = accelY;
  json_data["AccelZ"] = accelZ;
  json_data["GyroX"] = gyroX;
  json_data["GyroY"] = gyroY;
  json_data["GyroZ"] = gyroZ;
  json_data["MagX"] = magX;
  json_data["MagY"] = magY;
  json_data["MagZ"] = magZ;
  json_data["Roll_Mad6"] = roll_mad6;
  json_data["Pitch_Mad6"] = pitch_mad6;
  json_data["Yaw_Mad6"] = yaw_mad6;
  json_data["Roll_Mad9"] = roll_mad9;
  json_data["Pitch_Mad9"] = pitch_mad9;
  json_data["Yaw_Mad9"] = yaw_mad9;
  json_data["Roll_Mah6"] = roll_mah6;
  json_data["Pitch_Mah6"] = pitch_mah6;
  json_data["Yaw_Mah6"] = yaw_mah6;
  json_data["Roll_Mah9"] = roll_mah9;
  json_data["Pitch_Mah9"] = pitch_mah9;
  json_data["Yaw_Mah9"] = yaw_mah9;
  json_data["Temperature"] = temperature;
  json_data["Pressure"] = pressure;
  json_data["GroundPressure"] = ground_pressure;
  json_data["BMPAltitude"] = bmp_altitude;
  json_data["Altitude"] = altitude;
  json_data["AirSpeed"] = air_speed;
  json_data["PropellerRotationSpeed"] = propeller_rotation;
  json_data["Rudder"] = rudder_rotation;
  json_data["Elevator"] = elevator_rotation;
  json_data["Trim"] = trim;
  json_data["WiFiConnected"] = (WiFi.status() == WL_CONNECTED);
  json_data["IPAddress"] = WiFi.localIP().toString();
  json_data["CommAlive"] = (millis() - last_comm_time) < 1000;
  json_data["CommReceiveCount"] = comm_receive_count;
  json_data["WatchdogCount"] = watchdog_count;
  json_data["LoRaRSSI"] = 0;
  json_data["RunningTime"] = millis() / 1000.0;
  json_data["SDCardOK"] = sd_card_ok;
  json_data["SDLogCount"] = sd_log_count;
  json_data["SDWriteErrors"] = sd_write_errors;
  json_data["SDLastWriteAgoMs"] = millis() - sd_last_write_ms;
  json_data["SDFileSizeBytes"] = sd_file_size;

  json_array["data"] = json_data;

  // JSONフォーマットの文字列に変換する
  serializeJson(json_array, json_string, sizeof(json_string));
}
#pragma endregion


#pragma region AWS
#define THINGNAME "HPA"
// The MQTT topics that this device should publish/subscribe
#define AWS_IOT_PUBLISH_TOPIC "hpa/pub"

WiFiClientSecure net = WiFiClientSecure();
MQTTClient client = MQTTClient(256);

void connectAWS()
{
  WiFi.reconnect();
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
  }

  // Configure WiFiClientSecure to use the AWS IoT device credentials
  net.setCACert(AWS_CERT_CA);
  net.setCertificate(AWS_CERT_CRT);
  net.setPrivateKey(AWS_CERT_PRIVATE);

  // Connect to the MQTT broker on the AWS endpoint we defined earlier
  client.begin(AWS_IOT_ENDPOINT, 8883, net);

  Serial.println("Connecting to AWS IoT...");

  while (!client.connect(THINGNAME))
  {
    Serial.print(".");
    delay(100);
  }

  if (!client.connected())
  {
    Serial.println("AWS IoT Timeout!");
    return;
  }

  Serial.println("AWS IoT Connected!");
}

void publishMessage()
{
  client.publish(AWS_IOT_PUBLISH_TOPIC, json_string);
}

void AWS_task(void *parameter)
{
  connectAWS();
  while (1)
  {
    if (WiFi.status() != WL_CONNECTED || !client.loop())
    {
      Serial.println("AWS IoT Disconnected!");
      connectAWS();
    }
    publishMessage();
    delay(100);
  }
}
#pragma endregion

void watchdog_task(void *pvParameters)
{
  while (1)
  {
    if (watchdog_count > 5)
    {
      Serial.println("Watchdog triggered! Restarting...");
      ESP.restart();
    }
    watchdog_count++;
    delay(1000);
  }
}

void send_task(void *pvParameters)
{
  while (1)
  {
    if (WiFi.status() == WL_CONNECTED)
    {
     
      String gatewayIP = WiFi.gatewayIP().toString();
 
     
      wifiHttp.setConnectTimeout(300);
      wifiHttp.setTimeout(300);
 
      {
        String url_target = "http://" + gatewayIP + ":" + String(HTTP_PORT) + "/post";
        wifiHttp.begin(url_target);
        wifiHttp.POST((uint8_t *)json_string, strlen(json_string));
        wifiHttp.end();
      }
 
      {
        String url_target2 = "http://" + gatewayIP + ":" + String(SD_MONITOR_PORT) + "/post";
        wifiHttp.begin(url_target2);
        wifiHttp.POST((uint8_t *)json_string, strlen(json_string));
        wifiHttp.end();
      }
    }
    delay(50);
  }
}

void setup()
{
  Serial.begin(USB_BAUDRATE);
  COMMSerial.begin(COMM_SERIAL_BAUDRATE, SERIAL_8N1, COMM_RX, COMM_TX);

  auto cfg = M5.config();
  CoreS3.begin(cfg);
  CoreS3.Ex_I2C.begin();

  // Configure and start the WiFi station
  WiFi.mode(WIFI_STA);
  WiFi.persistent(true);      // 接続情報をフラッシュに保持
  WiFi.setAutoReconnect(true); // 切断時に自動で再接続する
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  InitNTP(); 
  delay(100);
  InitBMP280();
  delay(100);
  InitBMI270();
  delay(100);
  InitWiFiLocation();
  delay(100);
  InitTacho();
  delay(100);
  InitRPM();
  delay(100);
  InitAltitude();
  delay(100);
  InitSD();
  delay(100);
  

  // 最低でも8kBのスタックサイズが必要
  xTaskCreatePinnedToCore(AWS_task, "AWS_task", 16384, NULL, 1, NULL, 1);

  // スマホへのデータ送信用
  xTaskCreatePinnedToCore(send_task, "send_task", 8192, NULL, 1, NULL, 1);

  // 5秒以上データが更新されない場合にESP32をリセットする
  watchdog_count = 0;
  xTaskCreatePinnedToCore(watchdog_task, "watchdog_task", 2048, NULL, 1, NULL, 1);
}

void loop()
{
  CoreS3.update();
  
  GetBMP280();
  GetBMI270();
  GetNTPTime(); 
  GetAltitude();
  GetTacho();
  GetRPM();
  GetControlData();
  CreateJson();

  // Display
  static uint32_t last_print = 0;
  if (millis() - last_print > 500)
  {
    last_print = millis();

    CoreS3.Display.setCursor(0, 0);
    CoreS3.Display.clear();

    CoreS3.Display.printf("Temperature: %.2f *C\r\n", temperature);
    CoreS3.Display.printf("Pressure: %.2f Pa\r\n", pressure);
    CoreS3.Display.printf("Altitude: %.2f m\r\n", altitude);
    CoreS3.Display.printf("Date: %04d-%02d-%02d\r\n", gps_year, gps_month, gps_day);
    CoreS3.Display.printf("Time: %02d:%02d:%02d.%02d\r\n", gps_hour, gps_minute, gps_second, gps_centisecond);
    CoreS3.Display.printf("Latitude: %.6f, Longitude: %.6f\r\n", gps_latitude, gps_longitude);
    CoreS3.Display.printf("Location Accuracy: %.1f m (%s)\r\n", gps_accuracy, wifi_location_valid ? "valid" : "waiting");
    CoreS3.Display.printf("ax: %.2f, ay: %.2f, az: %.2f\r\n", accelX, accelY, accelZ);
    CoreS3.Display.printf("gx: %.2f, gy: %.2f, gz: %.2f\r\n", gyroX, gyroY, gyroZ);
    CoreS3.Display.printf("mx: %d, my: %d, mz: %d\r\n", magX, magY, magZ);
    CoreS3.Display.printf("Roll: %.2f, Pitch: %.2f, Yaw: %.2f\r\n", roll_mad9, pitch_mad9, yaw_mad9);
    CoreS3.Display.printf("Air Speed: %.2f\r\n", air_speed);
    CoreS3.Display.printf("Propeller Rotation Speed: %d\r\n", propeller_rotation);
    CoreS3.Display.printf("Rudder: %.2f, Elevator: %.2f, Trim: %d\r\n", rudder_rotation, elevator_rotation, trim);
    CoreS3.Display.printf("Wi-Fi Status: %s\r\n", WiFi.status() == WL_CONNECTED ? "Connected" : "Not Connected");
    CoreS3.Display.printf("IP Address: %s\r\n", WiFi.localIP().toString().c_str());
    bool comm_alive = (millis() - last_comm_time) < 1000; 
    CoreS3.Display.printf("COMM: %s (count:%lu)\r\n",comm_alive ? "HELLO Received" : "No Signal",(unsigned long)comm_receive_count);
    CoreS3.Display.printf("Watchdog count: %d\r\n", watchdog_count);
  }

  watchdog_count = 0;
}